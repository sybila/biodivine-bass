declare module 'bundle-text:*' {
    const s: string
    export default s
}

