const testData = [
  { label: 'BOT', lo: 0, hi: 0 },
  { label: 'TOP', lo: 1, hi: 1 },
  { label: 'Var8', lo: 0, hi: 1 },
  { label: 'Var7', lo: 1, hi: 0 },
  { label: 'Var0', lo: 3, hi: 1 },
  { label: 'Var9', lo: 0, hi: 1 },
  { label: 'Var8', lo: 5, hi: 0 },
  { label: 'Var0', lo: 6, hi: 5 },
  { label: 'Var1', lo: 0, hi: 1 },
  { label: 'Var0', lo: 1, hi: 0 },
  { label: 'Var9', lo: 1, hi: 0 },
  { label: 'Var8', lo: 0, hi: 10 },
  { label: 'Var0', lo: 5, hi: 0 },
  { label: 'Var8', lo: 1, hi: 0 },
  { label: 'Var5', lo: 13, hi: 0 },
];

export default testData;
