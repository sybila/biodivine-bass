//! Collection of all the necessary datatypes of the system.
pub mod adf;
mod bdd;
pub use bdd::*;
